<?php

declare(strict_types=1);

namespace Shlinkio\Shlink\Rest\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
}
