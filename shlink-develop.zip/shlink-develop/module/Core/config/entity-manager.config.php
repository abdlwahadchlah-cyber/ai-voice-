<?php

declare(strict_types=1);

return [

    'entity_manager' => [
        'orm' => [
            'entities_mappings' => [
                __DIR__ . '/../config/entities-mappings',
            ],
        ],
    ],

];
